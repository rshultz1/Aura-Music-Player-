# Aura Audio Player V2

A modern, futuristic 3D music player widget — fully self-contained and WordPress-compatible.

## WordPress Compatibility

This widget is built for drop-in WordPress use:

- **All CSS is scoped** under `.aura-ap` — no conflicts with themes or plugins
- **All IDs and classes** use the `aura-ap-` prefix to avoid collisions
- **JavaScript is wrapped** in an IIFE — no global variables, no jQuery dependency
- **No `<form>` tags** — avoids WordPress nesting issues
- **All elements use `button`** instead of `<a>` where appropriate
- **ARIA labels** included for accessibility compliance

### How to Add to WordPress

**Option A — Custom HTML Block (Gutenberg)**
1. Edit a page or post
2. Add a "Custom HTML" block
3. Paste the entire contents of `index.html`
4. Publish

**Option B — Page Builder**
1. Use any page builder (Elementor, Divi, WPBakery, Beaver Builder)
2. Add an "HTML" or "Code" module
3. Paste the contents of `index.html`

**Option C — Shortcode (for reuse)**
1. Add the HTML to a shortcode plugin (e.g., "Insert Headers and Footers" or a custom shortcode in functions.php)
2. Use `[aura_player]` wherever you want the player

**Option D — Full Page Template**
1. Use a blank/canvas page template (most themes support this)
2. Drop the code into a Custom HTML block for a full landing-page experience

## Features

- **3D Cover Art** with interactive mouse-tilt
- **3D Player Card** with glassmorphism, depth shadows, and glow
- **3D Review Text Box** — editable title, body (1000 char limit), and author field
- **Live Audio Visualizer** — 32-bar frequency display
- **8 Aura Color Presets** — Warm White, Coral, Sky Blue, Lavender, Mint, Gold, Rose, Teal
- **6 Border Color Presets** — Black, Charcoal, Silver, Bronze, Midnight, Forest
- **3 Shape Options** — Rounded, Square, Pill (applies to all 3D elements)
- **Toggleable Aura Glow, Download Button, and Review Box**
- **Editable Song Title & Artist** — click to edit inline
- **Drag & Drop Audio Upload** — MP3, WAV, OGG, FLAC
- **Cover Art Upload** — any image format
- **Share Button** — native share API or clipboard copy
- **Fully Responsive** — works on mobile and desktop

## Tech

- Pure HTML + CSS + Vanilla JavaScript (zero dependencies)
- Web Audio API for the visualizer
- CSS3 3D transforms, perspective, backdrop-filter
- Google Fonts: Outfit + Sora (loaded via CDN)

---

*Aura Audio Player V2 — Immersive Sound Experience*
